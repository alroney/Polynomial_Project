package polyPack;
/**
 * Author: Andrew Roney
 * Project Name: Polynomial_Project
 * Date: 09/06/2022
 * Class Description: Developer(ME) made syntax error response.
 */
public class InvalidPolynomialSyntax extends RuntimeException {
	InvalidPolynomialSyntax(String msg){
		super(msg);
	}
}
